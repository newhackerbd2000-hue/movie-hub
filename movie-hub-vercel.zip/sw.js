const V = 'mh-v4';
const SHELL = ['./', './index.html', './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png'];
const IMG_CACHE = 'mh-img-v1', API_CACHE = 'mh-api-v1', LIB_CACHE = 'mh-lib-v1';

self.addEventListener('install', e => {
  e.waitUntil(caches.open(V).then(c => c.addAll(SHELL)).catch(() => {}).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => ![V, IMG_CACHE, API_CACHE, LIB_CACHE].includes(k)).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

async function trim(name, max){
  const c = await caches.open(name), keys = await c.keys();
  if (keys.length > max) await Promise.all(keys.slice(0, keys.length - max).map(k => c.delete(k)));
}
async function networkFirst(req, cacheName, max, timeout){
  const c = await caches.open(cacheName);
  try {
    const r = await Promise.race([fetch(req), new Promise((_, rej) => setTimeout(() => rej(new Error('t')), timeout || 6000))]);
    if (r && r.ok) { c.put(req, r.clone()); if (max) trim(cacheName, max); }
    return r;
  } catch (err) {
    const hit = await c.match(req); if (hit) return hit; throw err;
  }
}
async function swr(req, cacheName, max){
  const c = await caches.open(cacheName), hit = await c.match(req);
  const net = fetch(req).then(r => { if (r && (r.ok || r.type === 'opaque')) { c.put(req, r.clone()); if (max) trim(cacheName, max); } return r; }).catch(() => hit);
  return hit || net;
}

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || req.headers.has('range')) return;
  const u = new URL(req.url);
  if (u.origin === location.origin) {
    if (req.mode === 'navigate') {
      e.respondWith(networkFirst(req, V, 0, 4000).catch(() => caches.match('./index.html')));
    } else e.respondWith(swr(req, V));
    return;
  }
  if (u.hostname === 'image.tmdb.org') return e.respondWith(swr(req, IMG_CACHE, 400));
  if (u.hostname === 'api.themoviedb.org') return e.respondWith(networkFirst(req, API_CACHE, 120, 6000));
  if (/fonts\.(googleapis|gstatic)\.com|cdnjs\.cloudflare\.com|cdn\.jsdelivr\.net|www\.gstatic\.com|i\.ibb\.co/.test(u.hostname)) return e.respondWith(swr(req, LIB_CACHE, 80));
});
