# MOVIE HUB – Vercel ডিপ্লয়

## ডিপ্লয় (২ মিনিট)
1. এই ফোল্ডারের সব ফাইল একটা GitHub রিপোতে আপলোড করুন (অথবা `vercel` CLI দিয়ে সরাসরি)।
2. vercel.com → Add New → Project → রিপো সিলেক্ট → Framework: **Other** → Deploy।
3. মোবাইলে Chrome-এ সাইট খুলুন → "অ্যাপ ইনস্টল করুন" ব্যানার/বাটন চাপুন। iPhone-এ Safari → Share → Add to Home Screen।

## ফাইল
- index.html – মূল অ্যাপ
- sw.js – অফলাইন ক্যাশ (অ্যাপ শেল, পোস্টার, API)
- manifest.webmanifest + icons/ – ইনস্টলযোগ্য অ্যাপ
- vercel.json – সঠিক হেডার

## জরুরি
- index.html-এ `ADMIN_PASSWORD` ও API key সবার দেখার মতো খোলা। Firebase Rules-এ লেখা বন্ধ রাখুন/অথ যোগ করুন এবং পাসওয়ার্ড বদলান।
- sw.js বদলালে `const V = 'mh-v4'` এর নাম বাড়ান (mh-v2…)।

## অ্যাপের ভেতরে ভিডিও দেখা (YouTube key)
"এখনই দেখুন" এখন বৈধ সোর্স থেকে চলে: আপনার যোগ করা ফাইল, Internet Archive-এর ফ্রি ফিল্ম, আর YouTube-এর এম্বেডযোগ্য ফুল ভিডিও (নাটক/টেলিফিল্ম ট্যাবসহ)।
YouTube অ্যাপের ভেতরে চালাতে একটা ফ্রি API key লাগবে:
1. console.cloud.google.com → নতুন প্রজেক্ট → "YouTube Data API v3" Enable
2. Credentials → Create API key → Application restrictions: HTTP referrers → আপনার vercel ডোমেইন দিন
3. index.html-এ `const YT_API_KEY = '';` এর ভেতরে key বসান, আবার Deploy করুন
(প্রতিদিন প্রায় ১০০টি সার্চ ফ্রি কোটায়)
